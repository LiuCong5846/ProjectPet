#!/bin/sh

chmod u+x ./export.sh
node index.js --export